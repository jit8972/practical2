<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Products;
use App\Order;
use Session;

class productsController extends Controller
{
    public function index()
    {
        $rand_number = mt_rand('111111','999999');
        Session::put('user_token',$rand_number);
            
        $products = Products::all();
        return view('products', compact('products'));
    }
    public function cart()
    {
        return view('cart');
    }
    
    public function addToCart($id)
    {
        try {
            $product = Products::find($id);
            if(!$product) {
                abort(404);
            }
            $cart = Session::get('cart');
            // if cart is empty then this the first product
            if(!$cart) {
                $cart = [
                        $id => [
                            "title" => $product->title,
                            "quantity" => 1,
                            "price" => $product->price,
                            "image" => $product->image,
                            'product_id' => $product->id
                        ]
                ];
                Session::put('cart', $cart);
                return redirect()->back()->with('success', 'products added to cart successfully!');
            }
            // if cart not empty then check if this product exist then increment quantity
            if(isset($cart[$id])) {
                $cart[$id]['quantity']++;
                Session::put('cart', $cart);
                return redirect()->back()->with('success', 'products added to cart successfully!');
            }
            // if item not exist in cart then add to cart with quantity = 1
            $cart[$id] = [
                "title" => $product->title,
                "quantity" => 1,
                "price" => $product->price
            ];
            Session::put('cart', $cart);
            return redirect()->back()->with('success', 'products added to cart successfully!');
        } catch (\Exception $e) {
            return view('error');
        }
    }

    public function update(Request $request)
    {
        if($request->id and $request->quantity)
        {
            $cart = Session::get('cart');
            $cart[$request->id]["quantity"] = $request->quantity;
            Session::put('cart', $cart);
            Session::flash('success', 'Cart updated successfully');
        }
    }
    public function remove(Request $request)
    {
        if($request->id) {
            $cart = Session::get('cart');
            if(isset($cart[$request->id])) {
                unset($cart[$request->id]);
                Session::put('cart', $cart);
            }
            Session::flash('success', 'products removed successfully');
        }
    }

    public function checkout(Request $request) {
        try {
            $token = Session::get('user_token');
            $cart = Session::get('cart');
            if(!empty($cart)){
                foreach($cart as $id => $detail) {
                    if($token) {
                        $order = Order::where('token', $token)
                        ->where('product_id', $detail['product_id'])
                        ->get()
                        ->toArray();

                        if(empty($order)) {
                            $products = Products::find($detail['product_id']);
                            
                            $order = new Order;
                            $order->token = $token;
                            $order->product_id = $products->id;
                            $order->user_id = 0;
                            $order->product_name = $products->title;
                            $order->product_description = $products->short_description;
                            $order->unit_price = $products->price;
                            $order->total_price = $products->price * $detail['quantity'];
                            $order->image = $products->image;
                            $order->status = 0;
                            $order->quantity = $detail['quantity'];
                            $order->save();
                        }
                    }
                }
                $products = Order::where('token',$token)->get();
                return view('checkout', compact('products'));
            }
        } catch (\Exception $e) {
            return view('error');
        }
    }

    public function clearcart(Request $request) {
        Session::forget('cart');
        return redirect('/');
    }

    public function confirmorder(Request $request) {
        Session::forget('cart');
        $token = Session::get('user_token');
        Order::where('token',$token)->update(['status'=>2]);
        return redirect('/');
    }

    public function myorder(Request $request) {
        $token = Session::get('user_token');
        $products = Order::where('token',$token)->get();
        return view('myorder', compact('products'));
    }
}
