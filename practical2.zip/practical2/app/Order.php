<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model {
    protected $table = 'order';
    protected $fillable = ['user_id', 'token', 'product_id', 'product_name', 'product_description', 'unit_price', 'image', 'quantity', 'total_price'];
}
