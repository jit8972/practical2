@extends('layouts.layout')
@section('title', 'Cart')
@section('content')
<p>Something went wrong</p>
@endsection