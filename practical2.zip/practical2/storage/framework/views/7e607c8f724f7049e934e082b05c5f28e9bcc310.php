
<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('content'); ?>
    <table id="cart" class="table table-hover table-condensed">
        <thead>
        <tr>
            <th style="width:50%">Product</th>
            <th style="width:10%">Price</th>
            <th style="width:8%">Quantity</th>
            <th style="width:22%" class="text-center">Subtotal</th>
        </tr>
        </thead>
        <tbody>
        <?php $total = 0 ?>
        <?php if(count($products) > 0): ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $total += $details['total_price'] ?>
                <tr>
                    <td data-th="Product">
                        <div class="row">
                            <div class="col-sm-3 hidden-xs"><img src="<?php echo e(asset('public/product_media/'.$details['image'])); ?>" width="100" height="100" class="img-responsive"/></div>
                            <div class="col-sm-9">
                                <h4 class="nomargin"><?php echo e($details['product_name']); ?></h4>
                            </div>
                        </div>
                    </td>
                    <td data-th="Price">$<?php echo e($details['unit_price']); ?></td>
                    <td data-th="Quantity">
                    <?php echo e($details['quantity']); ?>

                    </td>
                    <td data-th="Subtotal" class="text-center">$<?php echo e($details['total_price']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
        <tfoot>
        <!-- <tr class="visible-xs">
            <td class="text-center"><strong>Total <?php echo e($total); ?></strong></td>
        </tr> -->
        <tr>
            <td colspan="2" class="hidden-xs"></td>
            <td colspan="2" class="hidden-xs text-right"><strong>Total $<?php echo e($total); ?></strong></td>
        </tr>
        <tr>
            <td colspan="4" class="text-right">
                <a href="<?php echo e(url('/confirm-order')); ?>" class="btn btn-success"> Proceed</a>
            </td>
        </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practical\resources\views/checkout.blade.php ENDPATH**/ ?>