<?php

use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('products')->insert([
            'name' => 'User',
            'email' => 'user@yopmail.com',
            'username' => 'user',
            'role' => 'user',
            'password' => bcrypt('123456'),
        ]);
        
    }
}
