<?php

use Illuminate\Database\Seeder;

class ProductsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('products')->insert([
            'title' => 'Travel Bagpack',
            'short_description' => 'WATER RESISTANT WITH 1 YEAR WARRANTY - Stylish and durable backpack for school /college, daily casual use and travel. . Size: 18.5 inch X 13.5 inch X 9 inch.',
            'image' => '14.png',
            'price' => 92.00,
            'avail_qty' => '10'
        ]);
        \DB::table('products')->insert([
            'title' => 'Earphones',
            'short_description' => 'The stylish BassHeads 100 superior coated wired earphones are a definite fashion statement - wear your attitude with its wide variety of collection',
            'image' => '6.jpg',
            'price' => 129.99,
            'avail_qty' => '10'
        ]);
        \DB::table('products')->insert([
            'title' => 'Samsung Galaxy S9',
            'short_description' => 'A brand new, sealed Lilac Purple Verizon Global Unlocked Galaxy S9 by Samsung. This is an upgrade. Clean ESN and activation ready.',
            'image' => '55.png',
            'price' => 698.88,
            'avail_qty' => '10'
         ]);
         \DB::table('products')->insert([
             'title' => 'Apple iPhone X',
             'short_description' => 'GSM & CDMA FACTORY UNLOCKED! WORKS WORLDWIDE! FACTORY UNLOCKED. iPhone x 64gb. iPhone 8 64gb. iPhone 8 64gb. iPhone X with iOS 11.',
             'image' => '2.png',
             'price' => 983.00,
             'avail_qty' => '10'
         ]);
         \DB::table('products')->insert([
             'title' => 'Google Pixel 2 XL',
             'short_description' => 'New condition
 • No returns, but backed by eBay Money back guarantee',
             'image' => '3.jpg',
             'price' => 675.00,
             'avail_qty' => '10'
         ]);
         \DB::table('products')->insert([
             'title' => 'LG V10 H900',
             'short_description' => 'NETWORK Technology GSM. Protection Corning Gorilla Glass 4. MISC Colors Space Black, Luxe White, Modern Beige, Ocean Blue, Opal Blue. SAR EU 0.59 W/kg (head).',
             'image' => '4.jpg',
             'price' => 159.99,
             'avail_qty' => '10'
         ]);
         \DB::table('products')->insert([
             'title' => 'Huawei Elate',
             'short_description' => 'Cricket Wireless - Huawei Elate. New Sealed Huawei Elate Smartphone.',
             'image' => '5.jpg',
             'price' => 68.00,
             'avail_qty' => '10'
         ]);
         \DB::table('products')->insert([
             'title' => 'HTC One M10',
             'short_description' => 'The device is in good cosmetic condition and will show minor scratches and/or scuff marks.',
             'image' => '6.jpg',
             'price' => 129.99,
             'avail_qty' => '10'
         ]);
         \DB::table('products')->insert([
            'title' => 'Echo Dot (3rd Gen)',
            'short_description' => 'Echo Dot is our best selling smart speaker that can be operated by voice - even from a distance. Alexa can speak both English & Hindi, and new features are added automatically',
            'image' => '16.png',
            'price' => 1199.00,
             'avail_qty' => '10'
        ]);
        \DB::table('products')->insert([
            'title' => 'Electric Kettle',
            'short_description' => 'Max 3 differentiators Great Features - i)Automatic Cutoff ii) 360 Degree Swivel Base iii)Single Touch lid locking',
            'image' => '19.png',
            'price' => 599.00,
            'avail_qty' => '10'
        ]);
    }
}
